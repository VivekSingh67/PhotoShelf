import React from 'react'
import { fetchPhoto, fetchVideos } from './api/mediaApi'

const App = () => {
  return (
    <div className='h-screen text-white w-full bg-gray-950'>
      <button onClick={ async () =>{
         const data = await fetchPhoto('cat')
         console.log(data.results)
      }}>Get Button</button>

      <button onClick={ async () =>{
         const data = await fetchVideos('cat')
         console.log(data.videos)
      }}>Get Button</button>
    </div>
  )
}

export default App