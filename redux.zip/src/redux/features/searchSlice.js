import { createSlice } from "@reduxjs/toolkit";

const serachSlice = createSlice({
  name: "search",
  initialState: {
    query: "",
    activeTabs: "photos",
    results: [],
    loading: false,
    error: null,
  },
  reducers: {
    setQuert(state, action) {

    },
    setActiveTabs(state, action) {

    },
    setResults(state, action) {

    },
    setLoading(state, action) {

    },
    setError(state, action) {
        
    },
  },
});
